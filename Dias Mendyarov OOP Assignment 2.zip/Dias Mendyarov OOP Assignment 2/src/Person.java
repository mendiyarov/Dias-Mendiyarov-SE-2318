public class Person implements Comparable<Person>, Payable {
    private static int counter = 0;
    private int uniqueId;
    private String firstName;
    private String lastName;
    public Person() {
        this.uniqueId = ++counter;
    }
    public Person(String firstName, String lastName) {
        this();
        this.firstName = firstName;
        this.lastName = lastName;
    }
    public int getUniqueId() {
        return uniqueId;
    }
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    @Override
    public String toString() {
        return uniqueId + ". " + firstName + " " + lastName;
    }
    public String getRole() {
        return "Student";
    }
    public double getPaymentAmount() {
        return 0.0;
    }
    public int compareTo(Person otherPerson) {
        return Double.compare(this.getPaymentAmount(), otherPerson.getPaymentAmount());
    }
}