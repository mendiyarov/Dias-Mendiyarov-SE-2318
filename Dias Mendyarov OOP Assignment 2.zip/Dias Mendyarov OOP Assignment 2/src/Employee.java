public class Employee extends Person implements Comparable<Person>, Payable {
    private String jobPosition;
    private double monthlySalary;
    public Employee(String firstName, String lastName, String jobPosition, double monthlySalary) {
        super(firstName, lastName);
        this.jobPosition = jobPosition;
        this.monthlySalary = monthlySalary;
    }
    public String getJobPosition() {
        return jobPosition;
    }
    public double getMonthlySalary() {
        return monthlySalary;
    }
    public void setJobPosition(String jobPosition) {
        this.jobPosition = jobPosition;
    }
    public void setMonthlySalary(double monthlySalary) {
        this.monthlySalary = monthlySalary;
    }
    @Override
    public String toString() {
        return "Employee: " + super.toString();
    }
    public double getPaymentAmount() {
        return getMonthlySalary();
    }
    public int compareTo(Person otherPerson) {
        if (otherPerson instanceof Employee) {
            Employee otherEmployee = (Employee) otherPerson;
            return Double.compare(this.getMonthlySalary(), otherEmployee.getMonthlySalary());
        }
        return super.compareTo(otherPerson);
    }
}