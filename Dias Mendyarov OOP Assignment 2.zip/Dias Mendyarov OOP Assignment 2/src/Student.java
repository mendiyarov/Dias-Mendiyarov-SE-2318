public class Student extends Person implements Comparable<Person>, Payable {
    private double gradePointAverage;
    public Student(String firstName, String lastName, double gradePointAverage) {
        super(firstName, lastName);
        this.gradePointAverage = gradePointAverage;
    }
    public double getGradePointAverage() {
        return gradePointAverage;
    }
    public void setGradePointAverage(double gradePointAverage) {
        this.gradePointAverage = gradePointAverage;
    }
    @Override
    public String toString() {
        return "Student: " + super.toString();
    }
    public double getPaymentAmount() {
        return (getGradePointAverage() > 2.67) ? 36660.00 : 0.0;
    }
    public int compareTo(Person otherPerson) {
        if (otherPerson instanceof Student) {
            Student otherStudent = (Student) otherPerson;
            return Double.compare(this.getPaymentAmount(), otherStudent.getPaymentAmount());
        }
        return super.compareTo(otherPerson);
    }
}