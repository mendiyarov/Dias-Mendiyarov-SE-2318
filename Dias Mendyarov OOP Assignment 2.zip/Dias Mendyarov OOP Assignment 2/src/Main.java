import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
public class Main {
    public static void main(String[] args) {
        Employee emp1 = new Employee("John", "Lennon", "Manager", 27045.78);
        Employee emp2 = new Employee("George", "Harrison", "Developer", 50000.00);
        Student stu1 = new Student("Ringo", "Starr", 2.5);
        Student stu2 = new Student("Paul", "McCartney", 3.0);
        List<Person> peopleList = new ArrayList<>();
        peopleList.add(emp1);
        peopleList.add(emp2);
        peopleList.add(stu1);
        peopleList.add(stu2);
        Collections.sort(peopleList);
        printData(peopleList);
    }
    public static void printData(Iterable<Person> persons) {
        for (Person individual : persons) {
            if (individual instanceof Payable) {
                Payable payableIndividual = (Payable) individual;
                System.out.println(individual.toString() + " earns " + payableIndividual.getPaymentAmount() + " tenge");
            }
        }
    }
}